USE `videogamestoredb`;

-- 1 Seleziona tutti gli impiegati con una laurea in Economia.
SELECT Nome FROM impiegato WHERE TitoloStudio = 'Laurea in Economia';

-- 2 Seleziona gli impiegati che lavorano come Cassiere o che hanno un Diploma di Informatica. 
SELECT * FROM impiegato 
LEFT JOIN servizio_impiegato ON impiegato.CodiceFiscale = servizio_impiegato.CodiceFiscale
WHERE servizio_impiegato.Carica = 'Cassiere'
OR impiegato.TitoloStudio = 'Diploma di informatica';

-- 3 Seleziona i nomi e i titoli degli impiegati che hanno iniziato a lavorare dopo il 1 gennaio 2023. 
SELECT impiegato.Nome, impiegato.TitoloStudio
FROM impiegato
LEFT JOIN servizio_impiegato ON impiegato.CodiceFiscale = servizio_impiegato.CodiceFiscale
WHERE servizio_impiegato.DataInizio > '2023-01-01';

-- 4 Seleziona i titoli di studio distinti tra gli impiegati. 
SELECT DISTINCT TitoloStudio
FROM impiegato;

-- 5 Seleziona gli impiegati con un titolo di studio diverso da "Laurea in Economia".
 SELECT Nome FROM impiegato WHERE TitoloStudio <> 'Laurea in Economia';
 
-- 6 Seleziona gli impiegati che hanno iniziato a lavorare prima del 1 luglio 2023 e sono Commessi. 
SELECT impiegato.Nome
FROM impiegato
LEFT JOIN servizio_impiegato ON impiegato.CodiceFiscale = servizio_impiegato.CodiceFiscale
WHERE servizio_impiegato.DataInizio < '2023-07-01'
AND Carica = 'Commesso';

-- 7 Seleziona i titoli e gli sviluppatori dei videogiochi distribuiti nel 2020. 
SELECT Titolo, Sviluppatore
FROM videogioco
WHERE year(AnnoDistribuzione) = '2020';

USE `gestionale`;
-- 10 Seleziona tutti i prodotti con un prezzo superiore a 50 euro dalla tabella Prodotti. 
SELECT * FROM prodotti
WHERE Prezzo > '50';

-- 11 Seleziona tutte le email dei clienti il cui nome inizia con la lettera 'A' dalla tabella Clienti.
 SELECT Nome, Email FROM clienti
 WHERE Nome LIKE 'A%';
 
-- 12 Seleziona tutti gli ordini con una quantità maggiore di 10 o con un importo totale inferiore a 100 euro dalla tabella Ordini. 
INSERT INTO DettaglioOrdine (IDOrdine, IDProdotto, IDCliente, PrezzoTotale) SELECT
ord.IDOrdine,
ord.IDProdotto,
ord.IDCliente,
prd.prezzo * ord.quantità as PrezzoTotale
FROM Ordini ord JOIN Prodotti prd ON ord.IDProdotto = prd.IDProdotto;

SELECT * FROM ordini
JOIN dettaglioordine ON ordini.IDOrdine = dettaglioordine.IDOrdine
WHERE ordini.Quantità > 10
OR dettaglioordine.PrezzoTotale < 100;

-- 13 Seleziona tutti i prezzi dei prodotti il cui nome contiene la parola 'tech' indipendentemente dalla posizione nella tabella Prodotti. 
SELECT Prezzo FROM prodotti
WHERE NomeProdotto LIKE '%tech%';

-- 14 Seleziona tutti i clienti che non hanno un indirizzo email nella tabella Clienti. 
SELECT * FROM clienti
WHERE Email IS NULL;

-- 15 Seleziona tutti i prodotti il cui nome inizia con 'M' e termina con 'e' indipendentemente dalla lunghezza della parola nella tabella Prodotti.
SELECT * FROM prodotti
AND NomeProdotto LIKE 'M%e';