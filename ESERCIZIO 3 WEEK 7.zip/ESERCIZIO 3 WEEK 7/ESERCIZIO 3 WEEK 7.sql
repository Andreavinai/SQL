USE `chinook`;

-- 1 Elencate il numero di tracce per ogni genere in ordine discendente, escludendo quei generi che hanno meno di 10 tracce.
select count(track.GenreId) as tracks, genre.Name
from track join genre on track.GenreId = genre.GenreId
group by track.GenreId having tracks >10
order by tracks desc;

-- 2 Trovate le tre canzoni più costose.
SELECT Name, UnitPrice
FROM track
ORDER BY UnitPrice DESC
LIMIT 3;

-- 3 Elencate gli artisti che hanno canzoni più lunghe di 6 minuti.
select artist.Name
from artist
join album on artist.ArtistId = album.ArtistId
join track on track.AlbumId = album.AlbumId
where track.Milliseconds > 360000
group by ar.ArtistId;

-- 4 Individuate la durata media delle tracce per ogni genere.
SELECT genre.Name,
FLOOR(AVG(Track.Milliseconds/60000)) AS MINUTES, 
ROUND((AVG(Track.Milliseconds/60000)-FLOOR(AVG(Track.Milliseconds/60000)))*60) AS Seconds
FROM Genre
JOIN Track ON Track.GenreId = Genre.GenreId
GROUP BY Genre.Name
HAVING FLOOR(AVG(Track.Milliseconds/60000));

-- 5 Elencate tutte le canzoni con la parola “Love” nel titolo, ordinandole alfabeticamente prima per genere e poi per nome.
SELECT TrackId, Name
FROM Track
WHERE Name LIKE '%Love%'
ORDER BY GenreId, Name ASC;

-- 6 Trovate il costo medio per ogni tipologia di media.
SELECT mediatype.Name, AVG(track.UnitPrice)
FROM mediatype JOIN track ON mediatype.MediaTypeId = track.MediaTypeId
GROUP BY mediatype.Name;

-- 7 Individuate il genere con più tracce.
SELECT genre.Name, COUNT(track.Name)
FROM genre
JOIN track ON genre.GenreId = track.GenreId
GROUP BY genre.Name
ORDER BY COUNT(track.Name) DESC
LIMIT 1;

-- 8 Trovate gli artisti che hanno lo stesso numero di album dei Rolling Stones.
SELECT A1.Name
FROM Artist A1
JOIN Album AL1 ON A1.ArtistId = AL1.ArtistId
JOIN (SELECT COUNT(*) AS NumAlbums FROM Album
WHERE ArtistId = (SELECT ArtistId FROM Artist
WHERE Name = 'The Rolling Stones')) AS RS 
ON RS.NumAlbums = (SELECT COUNT(*) AS NumAlbums
FROM Album WHERE ArtistId = A1.ArtistId)
WHERE A1.Name != 'The Rolling Stones'
GROUP BY A1.name;
