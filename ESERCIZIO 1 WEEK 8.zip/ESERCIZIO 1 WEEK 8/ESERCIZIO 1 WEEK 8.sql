USE sakila;

-- 1 Effettuate un’esplorazione preliminare del database. Di cosa si tratta? Quante e quali tabelle contiene? Fate in modo di avere un’idea abbastanza chiara riguardo a con cosa state lavorando. 
SHOW tables;

-- 2 Scoprite quanti clienti si sono registrati nel 2006. 
SELECT DISTINCT COUNT(*)
FROM customer
WHERE YEAR(create_date) = 2006;

-- 3 Trovate il numero totale di noleggi effettuati il giorno 2006-02-14. 
SELECT COUNT(rental_id)
FROM rental
WHERE DATE(rental_date) = '2006-02-14';

-- 4 Elencate tutti i film noleggiati nell’ultima settimana e tutte le informazioni legate al cliente che li ha noleggiati. 
SELECT f.film_id, f.title, c.customer_id, c.first_name, c.last_name, r.rental_date
FROM rental AS r
JOIN inventory AS i ON r.inventory_id = i.inventory_id
JOIN film AS f ON i.film_id = f.film_id
JOIN customer AS c ON r.customer_id = c.customer_id
WHERE r.rental_date BETWEEN '2006-02-14' AND '2006-02-07';

SELECT f.film_id, f.title, c.customer_id, c.first_name, c.last_name, r.rental_date
FROM rental AS r
JOIN inventory AS i ON r.inventory_id = i.inventory_id
JOIN film AS f ON i.film_id = f.film_id
JOIN customer AS c ON r.customer_id = c.customer_id
WHERE r.rental_date >= (SELECT DATE_SUB(MAX(rental_date), INTERVAL 1 WEEK) FROM rental);

-- 5 Calcolate la durata media del noleggio per ogni categoria di film.
SELECT c.name AS category, SEC_TO_TIME(AVG(DATEDIFF(r.return_date, r.rental_date)) * 86400) AS avg_rental_duration
FROM category c
JOIN film_category fc USING(category_id)
JOIN film f USING(film_id)
JOIN inventory i USING(film_id)
JOIN rental r USING(inventory_id)
GROUP BY c.name;

-- 6 Trovate la durata del noleggio piu lungo.
SELECT MAX(rental_duration) AS Noleggio_piu_lungo
FROM film
LIMIT 1;
