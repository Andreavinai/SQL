USE `chinook`;

SHOW TABLES;

-- 1 Recuperate tutte le tracce che abbiano come genere “Pop” o “Rock”.
SELECT track.Name AS trackname, genre.Name AS genrename 
FROM track
LEFT JOIN genre ON track.GenreId = genre.GenreId
WHERE genre.Name IN ('Pop', 'Rock');

-- 2 Elencate tutti gli artisti e/o gli album che inizino con la lettera “A”.
SELECT artist.Name AS artistname, album.Title AS albumtitle 
FROM artist
RIGHT JOIN album ON artist.ArtistId = album.ArtistId
WHERE (album.Title LIKE "A%"
AND artist.Name LIKE "A%")
AND album.Title IS NOT NULL;

SELECT artist.Name AS artistname, album.Title AS albumtitle 
FROM artist
LEFT JOIN album ON artist.ArtistId = album.ArtistId
WHERE album.Title LIKE "A%"
OR artist.Name LIKE "A%"
AND album.Title IS NOT NULL;

-- 4 Elencate tutte le tracce che hanno come genere “Jazz” o che durano meno di 3 minuti.
SELECT track.Name AS trackname, genre.Name AS genrename, track.Milliseconds/60000 AS durata
FROM track
JOIN genre ON track.GenreId = genre.GenreId
WHERE genre.Name IN ('Jazz')
OR track.Milliseconds/60000 < 3;

-- 5 Recuperate tutte le tracce più lunghe della durata media.
SELECT
Name,
CONCAT(FLOOR(Milliseconds / 60000), ':', LPAD(FLOOR((Milliseconds % 60000) / 1000), 2, '0')) AS durata
FROM track
WHERE Milliseconds > (SELECT AVG(Milliseconds) FROM track);

SELECT * FROM track
WHERE track.Milliseconds > (SELECT AVG(track.Milliseconds) FROM track);

-- 6 Individuate i generi che hanno tracce con una durata media maggiore di 4 minuti.
SELECT genre.Name AS genrename FROM track 
INNER JOIN genre ON track.GenreId = genre.GenreId
GROUP BY genre.GenreId
HAVING AVG(track.Milliseconds) > 240000;

-- Individuate gli artisti che hanno rilasciato più di un album.
