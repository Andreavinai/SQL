-- Creazione Database
CREATE SCHEMA ToysGroup;
USE ToysGroup;

-- Creazione tabella Category.
CREATE TABLE Category (
    CategoryID INT PRIMARY KEY NOT NULL,
    CategoryName VARCHAR(50) NOT NULL
);

-- Creazione tabella Product.
CREATE TABLE Product (
    ProductID INT PRIMARY KEY NOT NULL,
    ProductName VARCHAR(50) NOT NULL,
    CategoryID INT NOT NULL,
    FOREIGN KEY (CategoryID) REFERENCES Category(CategoryID)
);

-- Creazione tabella Region.
CREATE TABLE Region (
    RegionID INT PRIMARY KEY NOT NULL,
    RegionName VARCHAR(50) NOT NULL
);

-- Creazione tabella State.
CREATE TABLE State (
    StateID INT PRIMARY KEY NOT NULL,
    StateName VARCHAR(50) NOT NULL,
    RegionID INT NOT NULL,
    FOREIGN KEY (RegionID) REFERENCES Region(RegionID)
);

-- Creazione tabella sales.
CREATE TABLE Sales (
    SaleID INT PRIMARY KEY NOT NULL,
    ProductID INT NOT NULL,
    StateID INT NOT NULL,
    SaleDate DATE NOT NULL,
    Revenue DECIMAL(10,2) NOT NULL,
    FOREIGN KEY (ProductID) REFERENCES Product(ProductID),
    FOREIGN KEY (StateID) REFERENCES State(StateID)
);

INSERT INTO Category (CategoryID, CategoryName) VALUES
(1, 'Costruzioni'),
(2, 'Peluche'),
(3, 'Bambole'),
(4, 'Videogiochi'),
(5, 'Carte'),
(6, 'Sport'),
(7, 'GiochidaTavola'),
(8, 'Costumi');

INSERT INTO Product (ProductID, ProductName, CategoryID) VALUES
(1, 'Lego', 1),
(2, 'Orsetto', 2),
(3, 'Barbie', 3),
(4, 'Fifa', 4),
(5, 'Uno', 5),
(6, 'Palla', 6),
(7, 'Cluedo', 7),
(8, 'IronMan', 8),
(9, 'Pes', 4),
(10, 'Skateboard', 6);

INSERT INTO Region (RegionID, RegionName) VALUES
(1, 'North Europe'),
(2, 'South Europe'),
(3, 'East Europe'),
(4, 'West Europe');

INSERT INTO State (StateID, StateName, RegionID) VALUES
(1, 'Italy', 2),
(2, 'France', 4),
(3, 'Greece', 2),
(4, 'Germany', 4),
(5, 'Finland', 1),
(6, 'Poland', 3),
(7, 'Portugal', 4),
(8, 'Spain', 4),
(9, 'England', 4);

INSERT INTO Sales (SaleID, ProductID, StateID, SaleDate, Revenue) VALUES
(1, 1, 3, '2024-01-17', 150.89),
(2, 2, 6, '2023-12-20', 29.75),
(3, 1, 1, '2023-03-10', 300.50),
(4, 4, 8, '2023-09-18', 139.98),
(5, 3, 9, '2023-02-07', 40.30),
(6, 9, 5, '2023-01-11', 209.97),
(7, 3, 4, '2023-07-21', 120.90),
(8, 4, 1, '2023-04-15', 69.99),
(9, 7, 7, '2024-02-18', 29.99),
(10, 2, 3, '2023-09-18', 139.98),
(11, 10, 2, '2023-09-07', 50.10),
(12, 8, 8, '2023-01-01', 45.19),
(13, 9, 6, '2023-07-21', 120.90),
(14, 10, 5, '2023-05-05', 69.99),
(15, 7, 9, '2024-03-08', 29.99),
(16, 8, 2, '2023-11-10', 90.38);

-- 1. Verificare che i campi definiti come PK siano univoci. 
SELECT COUNT(ProductID), COUNT(DISTINCT ProductID) FROM Product;
SELECT COUNT(RegionID), COUNT(DISTINCT RegionID) FROM Region;
SELECT COUNT(SaleID), COUNT(DISTINCT SaleID) FROM Sales;
SELECT COUNT(StateID), COUNT(DISTINCT StateID) FROM State;
SELECT COUNT(CategoryID), COUNT(DISTINCT CategoryID) FROM Category;

-- 2. Esporre l’elenco dei soli prodotti venduti e per ognuno di questi il fatturato totale per anno. 
SELECT p.ProductName, SUM(s.Revenue) AS TotalRevenue, YEAR(s.SaleDate) AS SaleYear
FROM Product p
INNER JOIN Sales s ON p.ProductID = s.ProductID
GROUP BY p.ProductName, YEAR(s.SaleDate)
ORDER BY YEAR(s.SaleDate);

-- 3. Esporre il fatturato totale per stato per anno. Ordina il risultato per data e per fatturato decrescente. 
SELECT st.StateName, SUM(s.Revenue) AS TotalRevenue, YEAR(s.SaleDate) AS SaleYear
FROM State st
INNER JOIN Sales s ON st.StateID = s.StateID
GROUP BY st.StateName, YEAR(s.SaleDate)
ORDER BY YEAR(s.SaleDate), TotalRevenue DESC;

-- 4. qual è la categoria di articoli maggiormente richiesta dal mercato? 
SELECT c.CategoryName, COUNT(*) AS TotalSales
FROM Category c
INNER JOIN Product p ON c.CategoryID = p.CategoryID
INNER JOIN Sales s ON p.ProductID = s.ProductID
GROUP BY c.CategoryName
ORDER BY TotalSales DESC
LIMIT 1;

-- 5. Rispondere alla seguente domanda: quali sono, se ci sono, i prodotti invenduti? Proponi due approcci risolutivi differenti. 
SELECT p.ProductName
FROM Product p
LEFT JOIN Sales s ON p.ProductID = s.ProductID
WHERE s.SaleID IS NULL;

SELECT ProductName
FROM Product
WHERE ProductID NOT IN (SELECT ProductID FROM Sales);

-- 6. Esporre l’elenco dei prodotti con la rispettiva ultima data di vendita (la data di vendita più recente).
SELECT p.ProductName, MAX(s.SaleDate) AS LastSaleDate
FROM Product p
LEFT JOIN Sales s ON p.ProductID = s.ProductID
WHERE s.SaleDate IS NOT NULL
GROUP BY p.ProductName;

/* BONUS: Esporre l’elenco delle transazioni indicando nel result set il codice documento, la data, il nome del prodotto, 
la categoria del prodotto, il nome dello stato, il nome della regione di vendita e un campo booleano valorizzato in base 
alla condizione che siano passati più di 180 giorni dalla data vendita o meno (>180 -> True, <= 180 -> False)
*/
