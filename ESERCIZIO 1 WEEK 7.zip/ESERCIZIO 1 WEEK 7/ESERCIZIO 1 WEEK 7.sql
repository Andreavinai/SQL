USE `chinook`;

SHOW TABLES ;

SELECT * FROM album;

-- 1 MOSTRA PRIME 10 RIGHE TABELLA album.
SELECT * FROM album
LIMIT 10;

-- TROVATE NUMERO TOTALE CANZONI TABELLA track.
SELECT COUNT(*) FROM track;

-- TROVATE I DIVERSI GENERI NELLA TABELLA generi.
SELECT DISTINCT Name FROM genre;

-- 2 RECUPERARE IL NOME DI TUTTE LE TRACCE E GENERE ASSOCIATO.
SELECT track.name AS trackname, genre.name AS genrename 
FROM track LEFT JOIN genre ON track.GenreId = genre.GenreId
ORDER BY genrename;

-- 3 RECUPERARE IL NOME DI TUTTI GLI ARTISTI CHE HANNO ALMENO UN ALBUM NEL DATABASE. ESISTONO ARTISTI SENZA ALBUM NEL DATABASE?
SELECT DISTINCT artist.name FROM artist 
JOIN album ON artist.ArtistId = album.ArtistId;

select album.Title, artist.Name
from album
right join artist 
ON album.ArtistId= artist.ArtistId
where AlbumId is null;

SELECT artist.Name FROM artist
WHERE EXISTS (SELECT album.AlbumId FROM album WHERE artist.ArtistId = album.ArtistId)
ORDER BY 1;

-- 4 Recuperate il nome di tutte le tracce, del genere associato e della tipologia di media. Esiste un modo per recuperare il nome della tipologia di media?
SELECT track.Name AS trackname, genre.Name AS genrename, mediatype.Name AS medianame
FROM track
INNER JOIN genre ON track.GenreId = genre.GenreId
INNER JOIN mediatype ON track.MediaTypeId = mediatype.MediaTypeId
GROUP BY track.Name, genre.Name, mediatype.Name;

-- 5 Elencate i nomi di tutti gli artisti e dei loro album.
SELECT artist.Name AS artistname, album.Title AS albumtitle
FROM artist RIGHT JOIN album ON artist.ArtistId = album.ArtistId
WHERE album.Title IS NOT NULL
ORDER BY artist.Name;

-- 6
SELECT album.Title AS albumtitle, AVG(track.Milliseconds)/1000 AS averagetrack
FROM album
JOIN track ON album.AlbumId = track.AlbumId
GROUP BY album.AlbumId;
